cat > quantum_locker.py << 'EOF'
#!/usr/bin/env python3
import os
import time

class QuantumLocker:
    def __init__(self):
        self.msg = """
╔══════════════════════════════════════════╗
║     ☠️ QUANTUM_Ω_RANSOMWARE v3.0 ☠️      ║
╠══════════════════════════════════════════╣
║  YOUR FILES HAVE BEEN ENCRYPTED!         ║
║  Send 0.05 BTC to: 1QuantumΩVerse1337    ║
║  ☠️ NO ESCAPE - SYSTEM LOCKED ☠️         ║
╚══════════════════════════════════════════╝
"""
    def run(self):
        while True:
            os.system('clear')
            print(self.msg)
            time.sleep(3)

if __name__ == '__main__':
    QuantumLocker().run()
EOF
